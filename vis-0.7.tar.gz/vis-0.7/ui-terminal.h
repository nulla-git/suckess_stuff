#ifndef UI_TERMINAL_H
#define UI_TERMINAL_H

#include "ui.h"

Ui *ui_term_new(void);
void ui_term_free(Ui*);

#endif
