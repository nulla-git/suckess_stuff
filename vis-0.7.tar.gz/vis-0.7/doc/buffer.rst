Buffer
======

.. doxygenfile:: buffer.h
